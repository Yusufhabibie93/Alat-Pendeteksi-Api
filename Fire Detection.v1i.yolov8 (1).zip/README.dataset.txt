# Fire Detection > 2024-07-23 7:48am
https://universe.roboflow.com/sage-mode/fire-detection-p9pot

Provided by a Roboflow user
License: CC BY 4.0

